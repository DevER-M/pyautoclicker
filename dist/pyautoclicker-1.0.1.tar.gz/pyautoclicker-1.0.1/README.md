# Auto-Clicker
_this is a very good autoclicker, easy to use.
this is made with `pynput`._

**This clicks at 62-100 cps which is more than enough.**
****

## Usage in Minecraft
__You can run this programme in the background and just press `s` to start autoclicking for a important pvp situation and stop it by pressing `s` again.__

__To end the programme press `e` to end the programme fully.__

<span style="color:red">***But autoclicking in minecraft can ban you in a server***</span>.

#### To implement the autoclicker 
**steps:**

1. open `cmd` and type `pip install auto-clicker`

2. open a python file 

3. ***type in the following***

`import pyautoclicker as pyac`  

`pyac.autoclick()`

__and your done!__

**[__Click me to see the code__](https://github.com/DevER-M/pyautoclicker)**
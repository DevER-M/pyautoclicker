Change log
==========

1.0.5(22/6/2021)
------------------

* __Added optional parameter 'delay'__






